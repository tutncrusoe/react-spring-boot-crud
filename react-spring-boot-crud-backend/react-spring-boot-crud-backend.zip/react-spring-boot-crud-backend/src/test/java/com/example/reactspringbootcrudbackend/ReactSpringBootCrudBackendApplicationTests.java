package com.example.reactspringbootcrudbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactSpringBootCrudBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}

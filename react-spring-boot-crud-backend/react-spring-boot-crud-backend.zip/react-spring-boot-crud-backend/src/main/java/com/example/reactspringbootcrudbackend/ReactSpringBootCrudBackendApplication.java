package com.example.reactspringbootcrudbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactSpringBootCrudBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactSpringBootCrudBackendApplication.class, args);
	}

}
